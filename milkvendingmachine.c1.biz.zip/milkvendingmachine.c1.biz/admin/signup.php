<?php
include('include/config.php');

if (isset($_POST['sign'])) {
$name=$_POST["name"];
$pass=$_POST["psw"];
$email=$_POST["email"];
$phone=$_POST["phone"];

$sql = "INSERT INTO signup (NAME,PASSWORD,EMAIL,PHONE)
VALUES ('$name','$pass','$email','$phone')";

if ($conn->query($sql) === TRUE) {

printf ("Account id is %d.\n", mysqli_insert_id($conn));

echo '<script>alert("Account created successfully")</script>'; 

} else {
    #echo "Error: " . $sql . "<br>" . $conn->error;
    echo '<script>alert("Account not created")</script>'; 

}

    
}

$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="login_css.css">
<title>Sign in</title>

</head>

<body>
  <div class="center">
    <h1>Sign Up</h1>
    <form  name="register" method="post" autocomplete="off">
		<div class="txt_field">
			<input type="text" name="name" required>
			<span></span>
			<label>Name</label>
		</div>
		
		<div class="txt_field">
			<input type="password" name="psw" required>
			<span></span>
			<label>Password</label>
		</div>
		
		<div class="txt_field">
			<input type="email" name="email" required>			
			<span></span>
			<label>Email</label>
		</div>
		
		<div class="txt_field">
			<input type="text" name="phone" required>
			<span></span>
			<label>Phone</label>
		</div>
		
      
	  <input type="submit" value="Create account" name="sign">
	  <div class="signup_link">
	   Already have an account?<a href="index.php"> Login</a>
            
                
    </div>
     
</body>

</html>
