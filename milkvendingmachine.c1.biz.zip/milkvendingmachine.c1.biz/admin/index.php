<?php
session_start();
error_reporting(0);
include('include/config.php');
if ($_SESSION['login'] != '') {
    $_SESSION['login'] = '';
}
if (isset($_POST['login'])) {
    $userid = $_POST['userid'];
    $password = $_POST['password'];
	
    $sql = "select USERID,PASSWORD from signup where USERID='$userid' and PASSWORD='$password'";
    $result = $con->query($sql);

   
    if ($result->num_rows > 0) {
    
        $_SESSION['alogin'] = $_POST['userid'];
        echo "<script type='text/javascript'> document.location = 'dashboard.php'; </script>";
    } else {

        echo "<script>alert('Invalid Details');</script>";
    }
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="login_css.css">
<title>Sign in</title>

</head>

<body>
  <div class="center">
    <h1>Login</h1>
    <form  name="register" method="post" autocomplete="off">
		<div class="txt_field">
			<input type="text" name="userid" required>
			<span></span>
			<label>User ID</label>
		</div>
		
		<div class="txt_field">
			<input type="password" name="password" required>
			<span></span>
			<label>Password</label>
		</div>
		
      <div class="pass"><a href="resetpassword.php">Forget Password?</a></div>
	  <input type="submit" value="Login" name="login">
	  <div class="signup_link">
	   Create an account?<a href="signup.php">Signup</a>
            
                
    </div>
     
</body>

</html>





