<?php
require ('fpdf/fpdf.php');
include('include/config.php');


$pdf= new FPDF('p','mm','A4');

    $pdf->AddPage();

    $pdf->SetFont('Arial','B','14');

    $pdf->Cell(190,10,'List of all Users','1,0');
	
    $pdf->Ln();

	$pdf->Cell(47, 10, "TRANSACTION ID ", 1, 0, 'L');
    $pdf->Cell(51, 10, "CARD NUMBER ",  1, 0, 'L');
    $pdf->Cell(65, 10, "BALANCE",  1, 0, 'L');
	$pdf->Cell(80, 10, "DATE",  1, 0, 'L');
	$pdf->Cell(75, 10, "TIME",  1, 0, 'L');


$pdf->Output();

    ?>
