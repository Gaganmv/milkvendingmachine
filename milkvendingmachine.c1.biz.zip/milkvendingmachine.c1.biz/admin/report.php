<?php
session_start();
//error_reporting(0);
include('include/config.php');
if (strlen($_SESSION['alogin']) == "") {
    header("Location: index.php");
} else {
    $stat=false;
    $id = $_POST['id'];

    $sdate = $_POST['sdate'];
    $edate = $_POST['edate'];

    //  echo($edate."------".$sdate);
    if ($sdate == "" && $edate == "") 
	{
        $logQuery = "SELECT TRANS_ID, CARD_NO, BALANCE, DATE, TIME FROM `transaction` where id='$id' ORDER BY `date` ASC";
    } else 
	{
        $logQuery = "SELECT * FROM `transaction` where date BETWEEN CAST('$sdate' AS DATE) AND CAST('$edate' AS DATE) AND id='$id'  ORDER BY `date` ASC";
    }
    $dataQuery = "SELECT TRANS_ID, CARD_NO, BALANCE, DATE, TIME from transaction where id='$id'";

    $log = array();
    $data = array();
    $temp = array();
    $temp2 = array();
    $query1 = $dbh->prepare($logQuery);
    if ($query1->execute()) {
        $res = $query1->fetchAll(PDO::FETCH_OBJ);
        if ($query1->rowCount() > 0) {
            foreach ($res as $result) {
                $temp['TRANS_ID'] = $result->date;
                $temp['CARD_NO'] = $result->time;
                $temp['BALANCE'] = $result->fat_content;
                $temp['DATE'] = $result->rate;
                $temp['TIME'] = $result->snf;
                array_push($log, $temp);
            }

            $query2 = $dbh->prepare($dataQuery);
            
            $stat=true;
        }
    }
   if($stat){
    $col_name = array();
    $col_name = ['TRANSACTION ID', 'CARD NUMBER', 'BALANCE', 'DATE', 'TIME'];
    //$col_name=array_keys($log[0]);
    //echo json_encode($col_name);
    require('fpdf/fpdf.php');
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->AliasNbPages();
    $pdf->SetFont('Arial', 'B', 18);

    $pdf->Cell(190, 10, "\"KSHRIA MITRA\"", 0, 1, 'C');
    $pdf->SetFont('Arial', 'B', 14);

    $pdf->Image("logo.jpg", 95, null, 20, 20);
    $pdf->Cell(190, 10, "Daily Transactions", 0, 1, 'C');
    if($payment==1)
    $pdf->Cell(190, 10, "Paid Log", 0, 1, 'C');
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Ln();
    $pdf->Cell(38, 10, "Farmer ID: " . $data['id'], 1, 0, 'L');
    $pdf->Cell(56, 10, "Name: " . $data['name'], 1, 0, 'L');
    $pdf->Cell(48, 10, "Village: " . $data['village'], 1, 0, 'L');
    $pdf->Cell(48, 10, "Phone: " . $data['phone'], 1, 0, 'L');
    $pdf->Ln();
    $pdf->Ln();
    $pdf->SetFont('Arial', 'B', 10);
    foreach ($col_name as $heading) {
        $pdf->Cell(27.14, 10, $heading, 1, 0, 'C');
    }
    $pdf->SetFont('Arial', '', 12);
    foreach ($log as $l) {
        $pdf->Ln();
        $dataVal = array_values($l);
        foreach ($dataVal as $column)
            $pdf->Cell(27.14, 10, $column, 1, 0, 'C');
    }
    $pdf->Ln();
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell((27.14 * 5), 10, "Total:", 1, 0, 'R');
    $pdf->Cell(27.14, 10, $totalQuantity, 1, 0, 'C');
    $pdf->Cell(27.14, 10, $totalAmount, 1, 0, 'C');
    $pdf->Output('D');
   }else{
    require('fpdf/fpdf.php');
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->AliasNbPages();
    $pdf->SetFont('Arial', 'B', 18);
    $pdf->Cell(190, 10, "\"KSHRIA MITRA\"", 0, 1, 'C');
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Image("logo.jpg", 95, null, 20, 20);

$pdf->Ln();$pdf->Ln();
    $pdf->Cell(190, 10, "No data found for  Farmer ID: ".$id.".. !", 0, 1, 'C');
    $pdf->Output('D');
   }
}
?>