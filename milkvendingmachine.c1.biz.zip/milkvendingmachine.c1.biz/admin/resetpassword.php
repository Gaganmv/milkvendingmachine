<?php
session_start();
error_reporting(0);
include('include/config.php');

if (isset($_POST['resetpassword'])) 
{
    $uid = $_POST['userid'];
	
	$query="select USERID from signup where USERID='$uid'";
	$result = mysqli_query($conn, $query);
	if (mysqli_num_rows($result) != 0)
	{
		  $sqlQuery = "SELECT USERID, NAME, PASSWORD, PHONE FROM signup where USERID='$uid'";
		   $q = $conn->prepare($sqlQuery);
			if ($q->execute()) 
			{
				$q->bind_result($userid, $name, $password, $phone);
				$temp = array();
				while ($q->fetch()) 
				{
					$temp['USERID'] = $userid;
					$temp['NAME'] = $name;
					$temp['PASSWORD'] = $password;
					$temp['PHONE'] = $phone;
            
				}

				$emailString = "Your+user+id+is+" . $temp['USERID'] . "+and+password+is+" . $temp['PASSWORD'];
				#echo $emailString;
				$url = "http://ulsms.digisapi.in/websms/sendsms.aspx?userid=kmitra&password=kmitra@123&sender=KMITRA&mobileno=" . $temp['PHONE'] . "&msg=" . $emailString . "";
				$response = file_get_contents($url);
				if ($response) 
				{
						$msg = "Password sent through SMS";
				}
				
			}
			
	}
	else
	{
            $msg = "Invalid User-ID ";
    }
       
}
    
?>



<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="login_css.css">
<title>Forget Password</title>

</head>

<body>
  <div class="center">
    <h1>Forget Password</h1>
	<?php if ($msg) { ?>
                                                <div class="alert alert-success left-icon-alert" role="alert">
                                                    <?php echo htmlentities($msg); ?>

                                                </div>
                                            <?php } if($button){ ?>
                                                <?php echo ($button); ?>
                                           <?php } ?>



    <form  name="register" method="post" autocomplete="off">
		<div class="txt_field">
			<input type="text" name="userid" required>
			<span></span>
			<label>User ID</label>
		</div>
		
	
		
      
	  
	  <div class="signup_link">
	   
         <input type="submit" value="Send" name="resetpassword">   
                
    </div>
      </form>
  </div>
     
</body>

</html>
